package com.example.viswa.msic.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.viswa.msic.Fragments.LyricsFragment;
import com.example.viswa.msic.Fragments.NowPlayingFragment;
import com.example.viswa.msic.InterProcessCommunication;
import com.example.viswa.msic.R;

public class MainActivity extends AppCompatActivity implements InterProcessCommunication<String> {

    boolean flag = true;
    TextView songNameClickListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMainActivity, new NowPlayingFragment()).commit();

        songNameClickListener = findViewById(R.id.songName);

        songNameClickListener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LyricsActivity.class);
                intent.putExtra("SongName", songNameClickListener.getText());
                startActivity(intent);
            }
        });

        final ImageButton playButton = findViewById(R.id.play);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(flag) {
                    playButton.setImageResource(R.drawable.baseline_pause_24);
                    flag = false;
                } else {
                    playButton.setImageResource(R.drawable.baseline_play_arrow_24);
                    flag = true;
                }
            }
        });


    }

    @Override
    public void registerEvent(String sName, String aName) {

        songNameClickListener.setText(sName);

        LyricsFragment lyricsFragment = new LyricsFragment ();
        Bundle bundle = new Bundle();
        bundle.putString("SongName", sName);
        bundle.putString("ArtistName", aName);
        lyricsFragment.setArguments(bundle);
        if (getSupportFragmentManager() != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .addToBackStack(null)
                    .replace(R.id.frameLayoutMainActivity, lyricsFragment)
                    .commit();
        }
    }

}