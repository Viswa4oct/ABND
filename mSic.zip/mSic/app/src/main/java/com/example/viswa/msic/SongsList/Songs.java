package com.example.viswa.msic.SongsList;

public class Songs {


    private int id;
    private String songName;
    private String artistName;

    public Songs(int id, String songName, String artistName) {
        this.id = id;
        this.songName = songName;
        this.artistName = artistName;
    }

    public int getId() {
        return id;
    }

    String getSongName() {
        return songName;
    }

    String getArtistName() {
        return artistName;
    }

}