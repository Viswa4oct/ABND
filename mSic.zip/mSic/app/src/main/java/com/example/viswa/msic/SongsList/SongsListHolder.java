package com.example.viswa.msic.SongsList;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.viswa.msic.R;

public class SongsListHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    private final TextView eventSongName;
    private final TextView eventArtistName;

    SongsListHolder(View view) {

        super(view);

        // inflate the UI widgets
        this.eventSongName = view.findViewById(R.id.tvSongDisplay);
        this.eventArtistName = view.findViewById(R.id.tvArtistDisplay);

        // set the onclick listener of the holder
        view.setOnClickListener(this);
    }

    void bindContact(Songs songs) {

        // bind the data to the view holder
        this.eventSongName.setText(songs.getSongName());
        this.eventArtistName.setText(songs.getArtistName());

    }

    @Override
    public void onClick(View v) {

    }
}