package com.example.viswa.msic.SongsList;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class SongsListAdapter extends RecyclerView.Adapter<SongsListHolder> {

    private final List<Songs> songsList;
    private int itemResource;

    public SongsListAdapter(int itemResource, List<Songs> songsList) {

        // Initialize our adapter
        this.songsList = songsList;
        this.itemResource = itemResource;
    }

    // override the onCreateViewHolder method
    @NonNull
    @Override
    public SongsListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // inflate the view and return the new ViewHolder
        View view = LayoutInflater.from(parent.getContext())
                .inflate(this.itemResource, parent, false);
        return new SongsListHolder(view);
    }

    // override the onBindViewHolder method
    @Override
    public void onBindViewHolder(@NonNull SongsListHolder holder, final int position) {

        // use position to access the correct Contacts object
        Songs songs = this.songsList.get(position);

        // bind the contacts object to the holder
        holder.bindContact(songs);
    }

    @Override
    public int getItemCount() {

        return this.songsList.size();
    }
}