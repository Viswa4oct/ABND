package com.example.viswa.msic.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.viswa.msic.Fragments.LyricsFragment;
import com.example.viswa.msic.Fragments.NowPlayingFragment;
import com.example.viswa.msic.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;

public class LyricsActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lyrics);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        String songName = getIntent().getExtras().getString("SongName", "Song");
        TextView songNameTV =  findViewById(R.id.songNameLyrics);
        songNameTV.setText(songName);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

            onBackPressed();

        return super.onOptionsItemSelected(item);

    }
}