package com.example.viswa.msic.Fragments;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.viswa.msic.InterProcessCommunication;
import com.example.viswa.msic.R;
import com.example.viswa.msic.RecyclerItemClickListener;
import com.example.viswa.msic.SongsList.Songs;
import com.example.viswa.msic.SongsList.SongsListAdapter;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class NowPlayingFragment extends Fragment {

    // Class List - Songs List
    List<Songs> songsList;
    // RecyclerView declaration
    RecyclerView listView;
    public InterProcessCommunication<String> mipic;

    final String[] songNames = {"Counting Stars", "A Sky Full Of Stars", "Darkside", "Uptown Funk",
            "Dark Horse", "Hymn For The Weekend", "Lean On", "Galway Girl", "We Don't Talk Anymore",
            "i hate u, i love u", "Something Just Like This", "Rockabye", "Alone", "Sun Is Never Going Down"
            , "All We Know", "Heathens", "Closer"};
    String[] artistNames = {"OneRepublic", "ColdPlay", "Alan Walker", "Mark Ronson", "Katy Perry",
            "ColdPlay", "Major Lazer", "Ed Sheeran", "Charlie Puth", "Gnash", "Something Just Like This",
            "Clean Bandit", "Alan Walker", "Martin Garrix", "The Chainsmokers", "Twenty One Pilots",
            "The Chainsmokers"};

    public NowPlayingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_now_playing, container, false);

        songsList = new ArrayList<>();

        for (int i = 0; i < songNames.length; i++) {
            songsList.add(new Songs(i, songNames[i], artistNames[i]));
        }

         mipic = (InterProcessCommunication<String>) getActivity();

        // Initialize the ContactAdapter
        final SongsListAdapter adapter = new SongsListAdapter(R.layout.custom_list, songsList);

        // Initialize the LayoutManager
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());

        // Initialize the ItemDecorators/ No decorators being used for this project.

        // setup the RecyclerView
        listView = view.findViewById(R.id.listView);

        // for performance, we say to the os that RecyclerView wont change size
        listView.setHasFixedSize(true);

        // set the LayoutManager
        listView.setLayoutManager(layoutManager);

        // set the ItemDecorators/ since no decorators this part of RecyclerView is also empty

        // attach the adapter to the RecyclerView
        listView.setAdapter(adapter);

        listView.addOnItemTouchListener(
                new RecyclerItemClickListener(getContext(), listView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, final int position) {

                        mipic.registerEvent(songNames[position], artistNames[position]);

                    }

                    @Override
                    public void onLongItemClick(View view, int position) {

                    }
                })
        );

        return view;
    }

}