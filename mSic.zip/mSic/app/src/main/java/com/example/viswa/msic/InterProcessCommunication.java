package com.example.viswa.msic;

public interface InterProcessCommunication<T> {
    void registerEvent(T sName, T aName);
}
