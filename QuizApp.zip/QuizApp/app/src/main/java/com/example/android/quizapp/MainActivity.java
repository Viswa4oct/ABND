package com.example.android.quizapp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final int q1Answer = R.id.Option1a;
    final int q4Answer = R.id.Option4b;
    final String q5Answer = "france";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private int checkFunction(int count, boolean answerCheckValue, TextView solution, TextView answer, LinearLayout color) {

        if (answerCheckValue) {
            count++;
            solution.setText("Correct Answer");
            solution.setVisibility(View.VISIBLE);
            answer.setVisibility(View.INVISIBLE);
            color.setBackgroundColor(Color.parseColor("#E8F5E9"));

        } else {
            solution.setText("Wrong Answer");
            solution.setVisibility(View.VISIBLE);
            answer.setVisibility(View.VISIBLE);
            color.setBackgroundColor(Color.parseColor("#FFCDD2"));
        }

        return count;

    }

    public void checkQuizAnswers(View view) {

        TextView SolutionText1 = findViewById(R.id.Solution1TextView);
        TextView SolutionText2 = findViewById(R.id.Solution2TextView);
        TextView SolutionText3 = findViewById(R.id.Solution3TextView);
        TextView SolutionText4 = findViewById(R.id.Solution4TextView);
        TextView SolutionText5 = findViewById(R.id.Solution5TextView);

        TextView AnswerText1 = findViewById(R.id.AnswerDisplayQ1);
        TextView AnswerText2 = findViewById(R.id.AnswerDisplayQ2);
        TextView AnswerText3 = findViewById(R.id.AnswerDisplayQ3);
        TextView AnswerText4 = findViewById(R.id.AnswerDisplayQ4);
        TextView AnswerText5 = findViewById(R.id.AnswerDisplayQ5);

        boolean answerOf1 = checkAnswer1();
        boolean answerOf2 = checkAnswer2();
        boolean answerOf3 = checkAnswer3();
        boolean answerOf4 = checkAnswer4();
        boolean answerOf5 = checkAnswer5();

        LinearLayout color1 = findViewById(R.id.colorDisplay1);
        LinearLayout color2 = findViewById(R.id.colorDisplay2);
        LinearLayout color3 = findViewById(R.id.colorDisplay3);
        LinearLayout color4 = findViewById(R.id.colorDisplay4);
        LinearLayout color5 = findViewById(R.id.colorDisplay5);

        int countOfCorrectAnswers = 0;

        countOfCorrectAnswers = checkFunction(countOfCorrectAnswers, answerOf1, SolutionText1, AnswerText1, color1);
        countOfCorrectAnswers = checkFunction(countOfCorrectAnswers, answerOf2, SolutionText2, AnswerText2, color2);
        countOfCorrectAnswers = checkFunction(countOfCorrectAnswers, answerOf3, SolutionText3, AnswerText3, color3);
        countOfCorrectAnswers = checkFunction(countOfCorrectAnswers, answerOf4, SolutionText4, AnswerText4, color4);
        countOfCorrectAnswers = checkFunction(countOfCorrectAnswers, answerOf5, SolutionText5, AnswerText5, color5);

        String message;

        if (countOfCorrectAnswers == 5) {
            message = "Congratualtions! You answered all correct";
        } else {
            message = countOfCorrectAnswers + "/5 correct.\n\n" + "Go through the correct answers.";
        }

        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    private boolean checkAnswer1() {
        RadioGroup radG = findViewById(R.id.RadioGroupOptions1);

        if (radG.getCheckedRadioButtonId() == q1Answer) {
            return true;
        }

        return false;
    }

    private boolean checkAnswer2() {
        CheckBox CB1 = findViewById(R.id.Option2a);
        CheckBox CB2 = findViewById(R.id.Option2b);
        CheckBox CB3 = findViewById(R.id.Option2c);
        CheckBox CB4 = findViewById(R.id.Option2d);

        if (CB1.isChecked() && CB2.isChecked() && CB3.isChecked() && CB4.isChecked()) {
            return true;
        }

        return false;
    }

    private boolean checkAnswer3() {
        CheckBox CB1 = findViewById(R.id.Option3a);
        CheckBox CB2 = findViewById(R.id.Option3b);
        CheckBox CB3 = findViewById(R.id.Option3c);
        CheckBox CB4 = findViewById(R.id.Option3d);

        if (CB1.isChecked() && !CB2.isChecked() && CB3.isChecked() && CB4.isChecked()) {
            return true;
        }

        return false;
    }

    private boolean checkAnswer4() {
        RadioGroup radG = findViewById(R.id.RadioGroupOptions4);

        if (radG.getCheckedRadioButtonId() == q4Answer) {
            return true;
        }

        return false;
    }

    private boolean checkAnswer5() {
        EditText editT = findViewById(R.id.EditTextAnswerQ5);

        return editT.getText().toString().equalsIgnoreCase(q5Answer);
    }
}

