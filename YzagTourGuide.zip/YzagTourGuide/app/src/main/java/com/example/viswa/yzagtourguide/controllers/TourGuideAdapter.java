package com.example.viswa.yzagtourguide.controllers;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.viswa.yzagtourguide.R;

import java.util.ArrayList;

public class TourGuideAdapter extends ArrayAdapter<TourGuide> {

    static class ViewHolder {

        ImageView eventImage;
        TextView eventName;
        TextView eventContent;
        TextView eventContact;

    }


    public TourGuideAdapter(@NonNull Context context, ArrayList<TourGuide> tourGuides) {
        super(context,0,tourGuides);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_details, parent, false);
        }

        TourGuide tourGuide = getItem(position);

        ViewHolder holder = new ViewHolder();
        holder.eventImage = convertView.findViewById(R.id.event_image);
        holder.eventName = convertView.findViewById(R.id.event_name);
        holder.eventContent = convertView.findViewById(R.id.event_content);
        holder.eventContact = convertView.findViewById(R.id.event_contact);
        convertView.setTag(holder);

        if (holder.eventImage != null) {
            holder.eventImage.setImageResource(tourGuide.getplaceImage());
            holder.eventImage.setVisibility(View.VISIBLE);
        } else {
            holder.eventImage.setVisibility(View.GONE);
        }


        holder.eventName.setText(tourGuide.getplaceName());


        holder.eventContent.setText(tourGuide.getplaceDescription());


        if (holder.eventContact != null) {
            holder.eventContact.setText(tourGuide.getPlaceContact());
            holder.eventContact.setVisibility(View.VISIBLE);
        } else {
           holder. eventContact.setVisibility(View.GONE);
        }

        return convertView;
    }

}
