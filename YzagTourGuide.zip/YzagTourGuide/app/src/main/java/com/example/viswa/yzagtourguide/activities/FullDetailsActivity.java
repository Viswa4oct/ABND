package com.example.viswa.yzagtourguide.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.viswa.yzagtourguide.R;

public class FullDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_details);

        String eventName = getIntent().getExtras().getString("Name","Name");
        String eventDesc;
        int eventImage = getIntent().getExtras().getInt("Image");
        setTitle(eventName);


        if(eventName.equals(getString(R.string.araku))) {
            eventDesc = getString(R.string.arakuDescFull);
        } else if(eventName.equals(getString(R.string.borra))){
            eventDesc = getString(R.string.borraDescFull);
        } else if(eventName.equals(getString(R.string.yarada))){
            eventDesc = getString(R.string.yaradaDescFull);
        } else if(eventName.equals(getString(R.string.simhachalam))){
            eventDesc = getString(R.string.simhachalamDescFull);
        } else if(eventName.equals(getString(R.string.lambasingi))){
            eventDesc = getString(R.string.lambasingiDescFull);
        } else if(eventName.equals(getString(R.string.kambalakonda))){
            eventDesc = getString(R.string.kambalakondaDescFull);
        } else if(eventName.equals(getString(R.string.tatipudi))){
            eventDesc = getString(R.string.tatipudiDescFull);
        } else if(eventName.equals(getString(R.string.katiki))){
            eventDesc = getString(R.string.katikiDescFull);
        } else if(eventName.equals(getString(R.string.duduma))){
            eventDesc = getString(R.string.dudumaDescFull);
        } else {
            eventDesc = getString(R.string.rkDescFull);
        }

        TextView descView = findViewById(R.id.event_desc_fullDetails);
        descView.setText(eventDesc);
        descView.setCompoundDrawablesWithIntrinsicBounds(0,eventImage,0,0);

    }
}