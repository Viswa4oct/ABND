package com.example.viswa.yzagtourguide.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.viswa.yzagtourguide.activities.FullDetailsActivity;
import com.example.viswa.yzagtourguide.R;
import com.example.viswa.yzagtourguide.controllers.TourGuide;
import com.example.viswa.yzagtourguide.controllers.TourGuideAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class NearbyPlacesFragment extends Fragment {


    public NearbyPlacesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_description_list, container,
                false);
        final ArrayList<TourGuide> tourGuideArrayList = new ArrayList<>();
        tourGuideArrayList.add(new TourGuide(getString(R.string.araku),
                getString(R.string.arakuDescription),R.drawable.araku));
        tourGuideArrayList.add(new TourGuide(getString(R.string.borra),
                getString(R.string.borraDescription),R.drawable.borra));
        tourGuideArrayList.add(new TourGuide(getString(R.string.yarada),
                getString(R.string.yaradaDescription),R.drawable.yarada));
        tourGuideArrayList.add(new TourGuide(getString(R.string.simhachalam),
                getString(R.string.simhachalamDescription),R.drawable.simhachalam));
        tourGuideArrayList.add(new TourGuide(getString(R.string.lambasingi),
                getString(R.string.lambasingiDescription),R.drawable.lambasingi));
        tourGuideArrayList.add(new TourGuide(getString(R.string.kambalakonda),
                getString(R.string.kambalakondaDescription),R.drawable.kambalakonda));
        tourGuideArrayList.add(new TourGuide(getString(R.string.tatipudi),
                getString(R.string.tatipudiDescription),R.drawable.tatipudi));
        tourGuideArrayList.add(new TourGuide(getString(R.string.katiki),
                getString(R.string.katikiDescription),R.drawable.katiki));
        tourGuideArrayList.add(new TourGuide(getString(R.string.duduma),
                getString(R.string.dudumaDescription),R.drawable.duduma));
        tourGuideArrayList.add(new TourGuide(getString(R.string.rk),
                getString(R.string.rkDescription),R.drawable.rk));

        TourGuideAdapter tourGuideAdapter = new TourGuideAdapter(getActivity(), tourGuideArrayList);
        ListView listView = rootView.findViewById(R.id.listView);
        listView.setAdapter(tourGuideAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TourGuide tourGuide = tourGuideArrayList.get(position);
                Intent intent = new Intent(getContext(), FullDetailsActivity.class);
                intent.putExtra("Name", tourGuide.getplaceName());
                intent.putExtra("Image", tourGuide.getplaceImage());
                startActivity(intent);
            }
        });

        return rootView;
    }

}