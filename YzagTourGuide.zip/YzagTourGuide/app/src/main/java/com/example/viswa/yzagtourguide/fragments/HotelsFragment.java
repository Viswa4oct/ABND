package com.example.viswa.yzagtourguide.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.viswa.yzagtourguide.R;
import com.example.viswa.yzagtourguide.controllers.TourGuide;
import com.example.viswa.yzagtourguide.controllers.TourGuideAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HotelsFragment extends Fragment {


    public HotelsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.place_description_list, container,
                false);
        final ArrayList<TourGuide> tourGuideArrayList = new ArrayList<>();
        tourGuideArrayList.add(new TourGuide(getString(R.string.thepark),
                getString(R.string.theparkDesc),R.drawable.thepark));
        tourGuideArrayList.add(new TourGuide(getString(R.string.novotel),
                getString(R.string.novotelDesc),R.drawable.novotel));
        tourGuideArrayList.add(new TourGuide(getString(R.string.sheraton),
                getString(R.string.sheratonDesc),R.drawable.sheraton));
        tourGuideArrayList.add(new TourGuide(getString(R.string.gateway),
                getString(R.string.gatewayDesc),R.drawable.gateway));
        tourGuideArrayList.add(new TourGuide(getString(R.string.dolphin),
                getString(R.string.dolphinDesc),R.drawable.dolphin));
        tourGuideArrayList.add(new TourGuide(getString(R.string.grand),
                getString(R.string.grandDesc),R.drawable.grand));

        TourGuideAdapter tourGuideAdapter = new TourGuideAdapter(getActivity(), tourGuideArrayList);
        ListView listView = rootView.findViewById(R.id.listView);
        listView.setAdapter(tourGuideAdapter);

        return rootView;

    }

}
