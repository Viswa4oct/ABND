package com.example.viswa.yzagtourguide.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.viswa.yzagtourguide.activities.FullDetailsActivity;
import com.example.viswa.yzagtourguide.R;
import com.example.viswa.yzagtourguide.controllers.TourGuide;
import com.example.viswa.yzagtourguide.controllers.TourGuideAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class CityAttractionsFragment extends Fragment {


    public CityAttractionsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_description_list, container,
                false);
        final ArrayList<TourGuide> tourGuideArrayList = new ArrayList<>();
        tourGuideArrayList.add(new TourGuide(getString(R.string.subMuseum),
                getString(R.string.subMuseumDesc),R.drawable.submuseum));
        tourGuideArrayList.add(new TourGuide(getString(R.string.kailasagiri),
                getString(R.string.kailasagiriDesc),R.drawable.kailasagiri));
        tourGuideArrayList.add(new TourGuide(getString(R.string.dnose),
                getString(R.string.dnoseDesc),R.drawable.dnose));
        tourGuideArrayList.add(new TourGuide(getString(R.string.zoo),
                getString(R.string.zooDesc),R.drawable.zoo));
        tourGuideArrayList.add(new TourGuide(getString(R.string.vuda),
                getString(R.string.vudaDesc),R.drawable.vuda));
        tourGuideArrayList.add(new TourGuide(getString(R.string.memorial),
                getString(R.string.memorialDesc),R.drawable.vas));
        tourGuideArrayList.add(new TourGuide(getString(R.string.vmuseum),
                getString(R.string.vmuseumDesc),R.drawable.vmuseum));

        TourGuideAdapter tourGuideAdapter = new TourGuideAdapter(getActivity(), tourGuideArrayList);
        ListView listView = rootView.findViewById(R.id.listView);
        listView.setAdapter(tourGuideAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TourGuide tourGuide = tourGuideArrayList.get(position);
                Intent intent = new Intent(getContext(), FullDetailsActivity.class);
                intent.putExtra("Name", tourGuide.getplaceName());
                intent.putExtra("Image", tourGuide.getplaceImage());
                startActivity(intent);
            }
        });

        return rootView;
    }

}