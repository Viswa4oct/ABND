package com.example.viswa.yzagtourguide.controllers;

public class TourGuide {

    private int placeImage;
    private String placeName;
    private String placeDescription;
    private String placeContact;

    public TourGuide(String placeName, String placeDescription, int placeImage) {
        this.placeImage = placeImage;
        this.placeName = placeName;
        this.placeDescription = placeDescription;
    }

    public TourGuide(String placeName, String placeDescription, String placeContact) {
        this.placeName = placeName;
        this.placeDescription = placeDescription;
        this.placeContact = placeContact;
    }

    public String getplaceDescription() {
        return placeDescription;
    }

    public int getplaceImage() {
        return placeImage;
    }

    public String getplaceName() {
        return placeName;
    }

    public String getPlaceContact() { return placeContact;}

}