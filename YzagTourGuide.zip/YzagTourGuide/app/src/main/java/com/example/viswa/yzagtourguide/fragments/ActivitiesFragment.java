package com.example.viswa.yzagtourguide.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.viswa.yzagtourguide.R;
import com.example.viswa.yzagtourguide.controllers.TourGuide;
import com.example.viswa.yzagtourguide.controllers.TourGuideAdapter;

import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class ActivitiesFragment extends Fragment {


    public ActivitiesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.place_description_list, container,
                false);
        final ArrayList<TourGuide> tourGuideArrayList = new ArrayList<>();
        tourGuideArrayList.add(new TourGuide(getString(R.string.scuba),
                getString(R.string.rushikonda),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.kayak),
                getString(R.string.rushikonda),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.paraglide),
                getString(R.string.rushikonda),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.paint),
                getString(R.string.kambala),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.snork),
                getString(R.string.rushikonda),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.zipliner),
                getString(R.string.kambala),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.goat),
                getString(R.string.kambala),getString(R.string.contact)));
        tourGuideArrayList.add(new TourGuide(getString(R.string.boating),
                getString(R.string.kambala),getString(R.string.contact)));


        TourGuideAdapter tourGuideAdapter = new TourGuideAdapter(Objects.requireNonNull(getActivity()), tourGuideArrayList);
        ListView listView = rootView.findViewById(R.id.listView);
        listView.setAdapter(tourGuideAdapter);

        return rootView;
    }

}
