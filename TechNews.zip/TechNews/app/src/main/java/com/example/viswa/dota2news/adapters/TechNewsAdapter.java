package com.example.viswa.dota2news.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.viswa.dota2news.R;
import com.example.viswa.dota2news.model.ModelClassNews;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TechNewsAdapter extends RecyclerView.Adapter<TechNewsAdapter.ViewHolder> {

    private List<ModelClassNews> listDota2News;
    private Context context;

    public TechNewsAdapter(Context context, List<ModelClassNews> newsList) {
        this.context = context;
        this.listDota2News = newsList;
    }

    @NonNull
    @Override
    public TechNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_news_card, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return listDota2News.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private TextView sectionName;
        private TextView webTitle;
        private TextView webPublicationDate;
        private TextView author;


        private ViewHolder(View itemNews) {
            super(itemNews);
            cardView = itemNews.findViewById(R.id.newsCardView);
            sectionName = itemNews.findViewById(R.id.sectionName);
            webTitle = itemNews.findViewById(R.id.webTitle);
            webPublicationDate = itemNews.findViewById(R.id.webPublicationDate);
            author = itemNews.findViewById(R.id.author);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ModelClassNews news = listDota2News.get(position);

        final String sectionName = news.getSectionName();
        holder.sectionName.setText(sectionName);

        final String webTitle = news.getWebTitle();
        holder.webTitle.setText(webTitle);

        final String webPublicationDate = news.getWebPublicationDate();
        holder.webPublicationDate.setText(formatDate(webPublicationDate));

        final String author = context.getString(R.string.hyphen, news.getAuthor());
        final String noAuthor = context.getString(R.string.noAuthor);
        if(news.getAuthor() != null) {
            holder.author.setText(author);
        } else {
            holder.author.setText(noAuthor);
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickWebUrl(news.getWebUrl());
            }
        });
    }

    private void onClickWebUrl(String openUrl) {
        Uri webPage = Uri.parse(openUrl);
        Intent i = new Intent(Intent.ACTION_VIEW, webPage);
        if(i.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(i);
        }
    }

    private String formatDate(String dateObject) {
        String dateFormatted = "";
        SimpleDateFormat inputDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault());
        SimpleDateFormat outputDate = new SimpleDateFormat("EEEE, dd.MM.yyyy", Locale.getDefault());
        try {
            Date newDate = inputDate.parse(dateObject);
            return outputDate.format(newDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateFormatted;
    }

    public void clearAll() {
        listDota2News.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<ModelClassNews> news) {
        listDota2News.clear();
        listDota2News.addAll(news);
        notifyDataSetChanged();
    }
}