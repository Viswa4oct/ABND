package com.example.viswa.dota2news.activities;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.viswa.dota2news.Utils.QueryUtils;
import com.example.viswa.dota2news.R;
import com.example.viswa.dota2news.adapters.TechNewsAdapter;
import com.example.viswa.dota2news.loaders.TechNewsLoader;
import com.example.viswa.dota2news.model.ModelClassNews;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<ModelClassNews>> {

    private TechNewsAdapter techNewsAdapter;
    private RecyclerViewEmptySupport recyclerViewEmptySupport;
    private TextView emptyMessage;
    private View emptyView;
    private View loadingSpinner;
    private List<ModelClassNews> modelClassNewsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewEmptySupport = findViewById(R.id.recyclerView);
        emptyView = findViewById(R.id.emptyView);
        emptyMessage = findViewById(R.id.emptyMessage);
        loadingSpinner = findViewById(R.id.loadingSpinner);

        // set empty view
        recyclerViewEmptySupport.setEmptyView(emptyView);

        // set the layout recyclerView
        recyclerViewEmptySupport.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEmptySupport.setItemAnimator(new DefaultItemAnimator());
        recyclerViewEmptySupport.setHasFixedSize(true);

        // Create a new adapter that takes an empty list of dota2News as input
        if (modelClassNewsList == null) modelClassNewsList = new ArrayList<>();
        techNewsAdapter = new TechNewsAdapter(this, modelClassNewsList);
        /* Setting adapter to recycler view. */
        recyclerViewEmptySupport.setAdapter(techNewsAdapter);

        // If there is a network connection, fetch data
        if (QueryUtils.isNetworkConnected(this)) {
            // Get a reference to the LoaderManager, in order to interact with loaders.
            LoaderManager loaderManager = getLoaderManager();
            // Initialize the loader. Pass in the int ID constant
            loaderManager.initLoader(1, null, this);
            // Otherwise, display error
        } else {
            upDateViewNoData();
        }
    }

    /**
     * This method update the views when no dat or
     * internet connection are available.
     */
    private void upDateViewNoData() {
        loadingSpinner.setVisibility(View.GONE);
        // Check if connected is true, display text if no data.
        // else no connected to internet display text no connection.
        if(QueryUtils.isNetworkConnected(this)) {
            emptyMessage.setText(getString(R.string.nodatafound));
        } else {
            emptyMessage.setText(getString(R.string.nointernet));
        }
    }

    /**
     * Instantiate and return a new Loader for the given ID.
     */
    @Override
    public Loader<List<ModelClassNews>> onCreateLoader(int id, Bundle args) {

        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this);
        // getString retrieve a String value for the max News item
        String maxNews = sharedPreferences.getString(
                getString(R.string.settings_max_news_key),
                getString(R.string.settings_max_news_default));
        // getString retrieve a String value for Order-By item
        String orderBy = sharedPreferences.getString(
                getString(R.string.settings_order_by_key),
                getString(R.string.settings_order_by_default));

        // parse breaks apart the URI string
        Uri baseUri = Uri.parse("http://content.guardianapis.com/search?q=tech&api-key=test");
        // buildUpon prepares the base Uri
        Uri.Builder builder = baseUri.buildUpon();
        // append query parameter
        builder.appendQueryParameter("show-tags", "contributor");
        builder.appendQueryParameter("order-by", orderBy);
        builder.appendQueryParameter("page-size", maxNews);

        // Create a new loader for the given URL
        return new TechNewsLoader(this, builder.toString());
    }

    @Override
    public void onLoadFinished(Loader<List<ModelClassNews>> loader, List<ModelClassNews> data) {
        // Clear the adapter of previous news data.
        techNewsAdapter.clearAll();

        // If there is a valid list of {@link News}
        if ((data != null) && !data.isEmpty()) {
            techNewsAdapter.addAll(data);
        } else { // set empty state
            upDateViewNoData();
        }
    }

    @Override
    public void onLoaderReset(Loader<List<ModelClassNews>> loader) {

        // Loader reset, so clear out existing data.
        techNewsAdapter.clearAll();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, SettingsActivity.class);
            startActivity(settingsIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}