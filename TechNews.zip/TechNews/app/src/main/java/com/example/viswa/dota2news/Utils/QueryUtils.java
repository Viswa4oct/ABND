package com.example.viswa.dota2news.Utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.util.Log;

import com.example.viswa.dota2news.model.ModelClassNews;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class QueryUtils {

    private static final String LOG_TAG = QueryUtils.class.getSimpleName();
    public static final int READ_TIMEOUT = 10000;
    public static final int CONNECT_TIMEOUT = 15000;
    public static final String REQUEST_METHOD = "GET";

    private QueryUtils() {
    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert cm != null;
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    public static List<ModelClassNews> fetchDota2NewsData(String requestUrl) {
        URL url = createUrl(requestUrl);

        // Perform HTTP request to the URL and receive a JSON response.
        String jsonResponse = null;
        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem making the HTTP request.", e);
        }

        // Extract relevant fields from the JSON response.

        return extractFeatureFromJson(jsonResponse);
    }

    private static URL createUrl(String requestUrl) {
        URL url = null;
        try {
            url = new URL(requestUrl);
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Problem building the URL", e);
        }
        return url;
    }

    private static String makeHttpRequest (URL url) throws IOException {
        String jsonResponse = "";

        // if URL is null, return early.
        if (url == null) {
            return jsonResponse;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(READ_TIMEOUT); // 10000 millisecond.
            urlConnection.setConnectTimeout(CONNECT_TIMEOUT); // 15000 millisecond.
            urlConnection.setRequestMethod(REQUEST_METHOD); // GET method.
            urlConnection.connect();

            // If the request is successful (response code 200)
            // Read the input stream and parse the response.
            if(urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readStreamResponse(inputStream);
            } else {
                Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem retrieving the Dota2News JSON results.", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readStreamResponse(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    private static List<ModelClassNews> extractFeatureFromJson(String dota2NewsJson) {
        // if the JSON string is empty or null then return early.
        if(TextUtils.isEmpty(dota2NewsJson)) {
            return null;
        }
        // create an empty ArrayList that we can start adding news to
        List<ModelClassNews> modelClassNewsList = new ArrayList<>();

        // Try to parse the JSON response string. If there's a problem with the way the JSON
        // is formatted, a JSONException exception object will be thrown.
        try {

            String webTitle;
            String sectionName;
            String webPublicationDate;
            String webUrl;
            String author = "";

            // Create a JSONObject from the JSON response string.
            JSONObject baseJsonResponse = new JSONObject(dota2NewsJson);
            // Extract the JSONObject associated with the key string "response"
            JSONObject responseJsonObject = baseJsonResponse.getJSONObject("response");
            // Extract the JSONArray associated with the key string "results"
            JSONArray resultsArray = responseJsonObject.getJSONArray("results");

            /* For each element in the resultArray, create a {@Link News} object */
            for (int i = 0; i < resultsArray.length(); i++) {
                // Get a single modelClassNews at index i
                JSONObject currentDota2News = resultsArray.getJSONObject(i);
                // Extract the value for the key called "newsHeadline"
                sectionName = currentDota2News.getString("sectionName");
                // Extract the value for the key called "newsTopic"
                webTitle = currentDota2News.getString("webTitle");
                webTitle = " \" " + webTitle + " \" ";
                // Extract the value for the key called "newsDate"
                webPublicationDate = currentDota2News.getString("webPublicationDate");
                // Extract the value for the key called "webUrl"
                webUrl = currentDota2News.getString("webUrl");
                // Extract the JSONArray associated with the key "tags"
                JSONArray tagsArray = currentDota2News.getJSONArray("tags");
                if(tagsArray.length() > 0) {
                    for(int j = 0; j < 1; j++) {
                        // extract the value for the key "webTitle" (author)
                        JSONObject authorObj = tagsArray.getJSONObject(j);
                        try {
                            author = authorObj.getString("webTitle");
                        } catch (JSONException e) {
                            Log.e(LOG_TAG, "Missing one or more author's name JSONObject");
                        }
                    }
                }

                // Create a new {@Link News} object
                ModelClassNews modelClassNews = new ModelClassNews(sectionName, webTitle,
                        webPublicationDate, webUrl, author);
                modelClassNewsList.add(modelClassNews);
            }
        } catch (JSONException e) {
            // catch the exception here, so the app doesn't crash. Print a log message.
            Log.e(LOG_TAG, "Problem parsing the news JSON results", e);
        }
        // Return the List
        return modelClassNewsList;
    }

}