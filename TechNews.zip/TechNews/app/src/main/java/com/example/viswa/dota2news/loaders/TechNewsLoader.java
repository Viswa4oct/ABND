package com.example.viswa.dota2news.loaders;

import android.content.AsyncTaskLoader;
import android.content.Context;

import com.example.viswa.dota2news.Utils.QueryUtils;
import com.example.viswa.dota2news.model.ModelClassNews;

import java.util.List;

public class TechNewsLoader
        extends AsyncTaskLoader<List<ModelClassNews>> {

    /* Query URL */
    private String url;

    public TechNewsLoader(Context context, String url) {
        super(context);
        this.url = url;
    }

    @Override
    protected void onStartLoading() {
        // Trigger the loadInBackground() method to execute.
        forceLoad();
    }

    @Override
    public List<ModelClassNews> loadInBackground() {
        if(url== null) {
            return null;
        }
        // Perform the network request, parse the response, and extract a list of news.
        List<ModelClassNews> newsData;
        newsData = QueryUtils.fetchDota2NewsData(url);
        return newsData;
    }
}