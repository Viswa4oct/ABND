package com.example.viswa.dota2news.activities;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;

/**
 * Source code for RecyclerViewEmptySupport taken from stackoverflow
 * https://stackoverflow.com/questions/28217436/how-to-show-an-empty-view-with-a-recyclerview
 * It implements an AdapterDataObserver that allows to set a view as the default empty layout
 * for our recyclerView.
 */

public class RecyclerViewEmptySupport extends RecyclerView {

    private View emptyView;

    // Adapter to observe changes and to work around adapter data
    final private AdapterDataObserver observer = new AdapterDataObserver() {
        @Override
        public void onChanged() {
            checkIfEmpty();
        }

        @Override
        public void onItemRangeInserted(int positionStart, int itemCount) {
            checkIfEmpty();
        }

        @Override
        public void onItemRangeRemoved(int positionStart, int itemCount) {
            checkIfEmpty();
        }
    };

    public RecyclerViewEmptySupport(Context context) {
        super(context);
    }

    public RecyclerViewEmptySupport(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RecyclerViewEmptySupport(Context context, AttributeSet attrs,
                             int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * Method to check if emptyView and adapter are not null.
     * If item count provided by the adapter is equal to zero, emptyView
     * is shown and the RecyclerViewEmptySupport is hidden.
     * If item count provided by the adapter is not zero, emptyView
     * is hidden and the RecyclerViewEmptySupport is shown.
     */
    void checkIfEmpty() {
        if (emptyView != null && getAdapter() != null) {
            final boolean emptyViewFlag =
                    getAdapter().getItemCount() == 0;
            emptyView.setVisibility(emptyViewFlag ? VISIBLE : GONE);
            setVisibility(emptyViewFlag ? GONE : VISIBLE);
        }
    }

    @Override
    public void setAdapter(Adapter adapter) {
        final Adapter oldAdapter = getAdapter();
        if (oldAdapter != null) {
            oldAdapter.unregisterAdapterDataObserver(observer);
        }
        super.setAdapter(adapter);
        if (adapter != null) {
            adapter.registerAdapterDataObserver(observer);
        }

        checkIfEmpty();
    }

    public void setEmptyView(View emptyView) {
        this.emptyView = emptyView;
        checkIfEmpty();
    }
}
