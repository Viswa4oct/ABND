package com.example.viswa.cricketscorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.viswa.cricketscorekeeper.R;

public class MainActivity extends AppCompatActivity {

    // Tracks the runs for Team A
    int runsTeamA = 0;

    // Tracks the runs for Team B
    int runsTeamB = 0;

    // Tracks the over count for Team A
    int oversTeamA = 0;

    // Tracks the over count for Team B
    int oversTeamB = 0;

    // Tracks the ball count for Team A
    int ballsTeamA = 0;

    // Tracks the ball count for Team B
    int ballsTeamB = 0;

    // Tracks the wickets for Team A
    int wicketsTeamA = 0;

    // Tracks the wickets for Team B
    int wicketsTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Increase the runs for Team A by 1.
     */
    public void addOneForTeamA(View v) {
        runsTeamA = runsTeamA + 1;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team A by 2.
     */
    public void addTwoForTeamA(View v) {
        runsTeamA = runsTeamA + 2;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team A by 3.
     */
    public void addThreeForTeamA(View v) {
        runsTeamA = runsTeamA + 3;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team A by 4.
     */
    public void addFourForTeamA(View v) {
        runsTeamA = runsTeamA + 4;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team A by 6.
     */
    public void addSixForTeamA(View v) {
        runsTeamA = runsTeamA + 6;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team A by 1 for extras(for multiple runs in extras use multiple times).
     */
    public void addExtrasForTeamA(View v) {
        runsTeamA = runsTeamA + 1;
        displayRunsForTeamA(runsTeamA);
    }

    /**
     * Increase the runs for Team B by 1.
     */
    public void addOneForTeamB(View v) {
        runsTeamB = runsTeamB + 1;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the runs for Team B by 2.
     */
    public void addTwoForTeamB(View v) {
        runsTeamB = runsTeamB + 2;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the runs for Team B by 3.
     */
    public void addThreeForTeamB(View v) {
        runsTeamB = runsTeamB + 3;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the runs for Team B by 4.
     */
    public void addFourForTeamB(View v) {
        runsTeamB = runsTeamB + 4;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the runs for Team B by 6.
     */
    public void addSixForTeamB(View v) {
        runsTeamB = runsTeamB + 6;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the runs for Team B by 1 for extras(for multiple runs in extras use multiple times).
     */
    public void addExtrasForTeamB(View v) {
        runsTeamB = runsTeamB + 1;
        displayRunsForTeamB(runsTeamB);
    }

    /**
     * Increase the over count for Team A.
     */
    public void addOneOverForTeamA(View v) {
        if (ballsTeamA == 5) {
            oversTeamA += 1;
            ballsTeamA = 0;
        } else
            ballsTeamA += 1;
        displayOversForTeamA(oversTeamA);
        displayBallsForTeamA(ballsTeamA);
    }

    /**
     * Increase the over count for Team B.
     */
    public void addOneOverForTeamB(View v) {
        if (ballsTeamB == 5) {
            oversTeamB += 1;
            ballsTeamB = 0;
        } else
            ballsTeamB += 1;
        displayOversForTeamB(oversTeamB);
        displayBallsForTeamB(ballsTeamB);
    }

    /**
     * Increase the wicket for Team A by 1.
     */
    public void addOneWicketForTeamA(View v) {
        if (wicketsTeamA < 10) {
            wicketsTeamA = wicketsTeamA + 1;
        } else
            wicketsTeamA = 10;
        displayWicketsForTeamA(wicketsTeamA);
    }

    /**
     * Increase the wicket for Team B by 1.
     */
    public void addOneWicketForTeamB(View v) {
        if (wicketsTeamB < 10) {
            wicketsTeamB = wicketsTeamB + 1;
        } else
            wicketsTeamB = 10;
        displayWicketsForTeamA(wicketsTeamB);
    }

    /**
     * Resets the runs for both teams back to 0.
     */
    public void resetruns(View v) {
        runsTeamA = 0;
        runsTeamB = 0;
        oversTeamA = 0;
        oversTeamB = 0;
        ballsTeamA = 0;
        ballsTeamB = 0;
        wicketsTeamA = 0;
        wicketsTeamB = 0;
        displayRunsForTeamA(runsTeamA);
        displayRunsForTeamB(runsTeamB);
        displayOversForTeamA(oversTeamA);
        displayOversForTeamB(oversTeamB);
        displayBallsForTeamA(ballsTeamA);
        displayBallsForTeamB(ballsTeamB);
        displayWicketsForTeamA(wicketsTeamA);
        displayWicketsForTeamB(wicketsTeamB);
    }

    /**
     * Displays the given runs for Team A.
     */
    public void displayRunsForTeamA(int runs) {
        TextView runsView = findViewById(R.id.teamA_runs);
        runsView.setText(String.valueOf(runs));
    }

    /**
     * Displays the given runs for Team B.
     */
    public void displayRunsForTeamB(int runs) {
        TextView runsView = findViewById(R.id.teamB_runs);
        runsView.setText(String.valueOf(runs));
    }

    /**
     * Displays the overs for Team A.
     */
    public void displayOversForTeamA(int overs) {
        TextView oversView = findViewById(R.id.teamA_over_count);
        oversView.setText(String.valueOf(overs));
    }

    /**
     * Displays the overs for Team B.
     */
    public void displayOversForTeamB(int overs) {
        TextView oversView = findViewById(R.id.teamB_over_count);
        oversView.setText(String.valueOf(overs));
    }

    /**
     * Displays the balls for Team A.
     */
    public void displayBallsForTeamA(int overs) {
        TextView oversView = findViewById(R.id.teamA_ball_count);
        oversView.setText(String.valueOf(overs));
    }

    /**
     * Displays the balls for Team B.
     */
    public void displayBallsForTeamB(int overs) {
        TextView oversView = findViewById(R.id.teamB_ball_count);
        oversView.setText(String.valueOf(overs));
    }

    /**
     * Displays the wickets for Team A.
     */
    public void displayWicketsForTeamA(int wks) {
        TextView wicketsView = findViewById(R.id.teamA_wickets);
        wicketsView.setText(String.valueOf(wks));
    }

    /**
     * Displays the wickets for Team B.
     */
    public void displayWicketsForTeamB(int wks) {
        TextView wicketsView = findViewById(R.id.teamB_wickets);
        wicketsView.setText(String.valueOf(wks));
    }
}
